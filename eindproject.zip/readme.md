# <u>Inleiding</u>
Accountantzijn.nl moet het go to platform worden voor dialoog omtrent finance vraagstukken en mogelijke samenwerking bij
het tackelen van deze vraagstukken. Accountantzijn.nl is informatief en interactief en is zo ingericht dat de belangrijkste
vraagstukken boven komen drijven. Het brengt vraagstukken en oplossers bij elkaar.

### Wat is het probleem?
Er ontbreekt een online interactief platform voor accountants om discussies te kunnen voeren over veranderingen en koers binnen het vakgebied.

### Wie zijn de verwachte gebruikers?
De accountant en het maatschappelijk verkeer.

### In welke setting wordt het project gebruikt?
Deze website is bedoeld om te gebruiken op verschillende formaten desktops, laptops, smartphones en tablets.

### Wat doet deze oplossing anders of beter dan bestaande oplossingen?
Voor zover bekend zijn er geen andere websites waar accountants op deze manier interactief met elkaar kunnen discussiëren over ontwikkelingen en koers binnen het vakgebied.

### <u>Website schets:</u>

#### Homepage:

![alt text](images/home.jpg)

#### blog:

![alt text](blog.jpg)

#### blog drill through

![alt text](blog_detail.jpg)

#### opinie:

![alt text](opinie.jpg)

#### dialoog:

![alt text](dialoog.jpg)

#### dialoog drill through:

![alt text](dialoog_detail.jpg)


